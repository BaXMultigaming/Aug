(function(){
    $J(window).trigger("resize");
})();
