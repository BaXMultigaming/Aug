(function(){
    $J("#recommended_block_content").trigger("v_contentschanged");
})();
