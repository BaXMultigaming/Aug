(function() {
    document.getElementById("es_invite_to_group").addEventListener("click", () => {
        ExecFriendAction("group_invite", "friends/all");
    });
})();
