(function(){
    pricehistory_zoomDays(
        SellItemDialog.m_plotPriceHistory,
        SellItemDialog.m_timePriceHistoryEarliest,
        SellItemDialog.m_timePriceHistoryLatest,
        365
    );
})();
