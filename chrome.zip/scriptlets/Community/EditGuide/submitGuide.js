(function() {
    SubmitGuide();
})();
